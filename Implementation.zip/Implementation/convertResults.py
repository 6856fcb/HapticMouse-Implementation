#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Analyze haptic testbed JSON logs.

- Reads:  ./results/result*.json  (each a list of per-trial dicts)
- Writes: ./out/*  (CSV + JSON summaries)

No external dependencies (pure Python).
"""

import os, json, glob, csv
from statistics import median, mean

IN_DIR  = os.path.join('.', 'results')
OUT_DIR = os.path.join('.', 'out')

os.makedirs(OUT_DIR, exist_ok=True)

# ---------- Utilities ----------

def safe_num(x):
    try:
        if x is None: return None
        if isinstance(x, (int, float)): return float(x)
        if isinstance(x, str) and x.strip()=='':
            return None
        return float(x)
    except Exception:
        return None

def med(nums):
    vals = [safe_num(v) for v in nums]
    vals = [v for v in vals if v is not None]
    return round(median(vals), 3) if vals else None

def avg(nums):
    vals = [safe_num(v) for v in nums]
    vals = [v for v in vals if v is not None]
    return round(mean(vals), 3) if vals else None

def summ(nums):
    vals = [safe_num(v) for v in nums]
    vals = [v for v in vals if v is not None]
    return round(sum(vals), 3) if vals else 0.0

def nvalid(nums):
    vals = [safe_num(v) for v in nums]
    return sum(1 for v in vals if v is not None)

def time_field(row):
    """Pick the most appropriate time for the trial, depending on task."""
    # Hunt has total time; others have time to correct
    return (
        safe_num(row.get('zeitBisKorrektMs')) or
        safe_num(row.get('latenzBisKaufenMs')) or  # legacy button test (if present)
        safe_num(row.get('gesamtzeitMs'))
    )

def ttnt_field(row):
    """For Hunt trials only."""
    return safe_num(row.get('ttntMedianMs'))

def misclicks_count(row):
    """Combine misclick variants into one comparable number."""
    keys = [
        'fehlklicks',           # general
        'fehlklicksExtern',     # help task extern
        'wiederholungsklicks'   # hunt repeats (often analyzed separately; we include in total, too)
    ]
    total = 0.0
    for k in keys:
        v = safe_num(row.get(k))
        if v is not None:
            total += v
    return total

def hover_total(row):
    """Sum hover counters if present."""
    keys = ['hoverExtern','hoverDeaktiviert','hoverZiel','hoverIntern','hoverZiele','hoverFallen','hoverPrimary','hoverSecondary']
    total = 0.0
    have_any = False
    for k in keys:
        v = safe_num(row.get(k))
        if v is not None:
            have_any = True
            total += v
    return (total if have_any else None)

def test_key(row):
    # Normalize common German/English labels to a stable short key
    t = (row.get('test') or '').strip().lower()
    if 'link' in t:
        return 'link'
    if 'hilfe' in t or 'help' in t:
        return 'help'
    if 'hunt' in t or 'klickbare' in t:
        return 'hunt'
    if 'schalt' in t or 'button' in t:
        return 'buttons'
    return t or 'unknown'

def cond_key(row):
    h = (row.get('haptik') or row.get('haptic') or '').strip().lower()
    if h in ('on','off'):
        return h
    # fallback to body state if ever stored differently
    return 'on' if h == 'true' else 'off' if h == 'false' else (h or 'unknown')

def pid(row):
    return str(row.get('participant') or row.get('teilnehmer') or row.get('pid') or 'UNKNOWN')

def to_int(x):
    v = safe_num(x)
    return int(v) if v is not None else None

# ---------- Load all trials ----------

all_trials = []
files = sorted(glob.glob(os.path.join(IN_DIR, 'result*.json')))
for fn in files:
    try:
        with open(fn, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                for r in data:
                    if isinstance(r, dict):
                        all_trials.append(r)
            elif isinstance(data, dict) and isinstance(data.get('results'), list):
                for r in data['results']:
                    if isinstance(r, dict):
                        all_trials.append(r)
    except Exception as e:
        print(f"[WARN] Could not read {fn}: {e}")

print(f"Loaded {len(all_trials)} trials from {len(files)} file(s).")

# If empty, stop gracefully
if not all_trials:
    with open(os.path.join(OUT_DIR, 'summary.json'), 'w', encoding='utf-8') as f:
        json.dump({'error':'no trials found','in_dir':IN_DIR}, f, indent=2)
    print("No trials found. Exiting.")
    raise SystemExit(0)

# ---------- Normalize & export merged trials ----------

merged = []
for r in all_trials:
    merged.append({
        'participant'      : pid(r),
        'haptik'           : cond_key(r),
        'test'             : test_key(r),
        'trial'            : to_int(r.get('trial')),
        'trials_total'     : to_int(r.get('trialsGesamt') or r.get('trials_total')),
        'target'           : r.get('ziel') or r.get('target'),
        'links_total'      : to_int(r.get('linksGesamt')),
        'goals_total'      : to_int(r.get('anzahlZiele') or r.get('goals_total')),
        'found'            : to_int(r.get('gefunden')),
        'success'          : bool(r.get('erfolg')) if r.get('erfolg') is not None else None,

        'time_ms'          : time_field(r),
        'ttnt_median_ms'   : ttnt_field(r),

        'misclicks_total'  : misclicks_count(r),
        'misclicks'        : safe_num(r.get('fehlklicks')),
        'misclicks_external': safe_num(r.get('fehlklicksExtern')),
        'repeat_clicks'    : safe_num(r.get('wiederholungsklicks')),

        'first_input_ms'   : safe_num(r.get('zeitBisErsteInteraktionMs')),
        'path_px'          : safe_num(r.get('pfadPx')),
        'scroll_px'        : safe_num(r.get('scrollPx')),
        'resizes'          : safe_num(r.get('resizeAnzahl')),
        'keys_activations' : safe_num(r.get('aktivierungenTastatur')),
        'pointer_activations': safe_num(r.get('aktivierungenPointer')),
        'hover_total'      : hover_total(r),

        # keep raw if present (omitted in CSV)
        'raw_mousePath'    : r.get('mousePath'),
        'raw_events'       : r.get('events')
    })

# Write merged JSON (lean without raw paths to keep file small)
lean = [{k:v for k,v in m.items() if not k.startswith('raw_')} for m in merged]
with open(os.path.join(OUT_DIR, 'merged_trials.json'), 'w', encoding='utf-8') as f:
    json.dump(lean, f, indent=2, ensure_ascii=False)

# Write merged CSV (without raw arrays)
csv_cols = [k for k in lean[0].keys()]
with open(os.path.join(OUT_DIR, 'merged_trials.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=csv_cols)
    w.writeheader()
    for row in lean:
        w.writerow(row)

# ---------- Aggregations ----------

# group: (participant, test, haptik)
from collections import defaultdict

groups = defaultdict(list)
for m in merged:
    key = (m['participant'], m['test'], m['haptik'])
    groups[key].append(m)

summary_rows = []
for (p, t, h), rows in groups.items():
    N = len(rows)
    succ = [r.get('success') for r in rows if r.get('success') is not None]
    succ_rate = round(100.0 * sum(1 for s in succ if s) / len(succ), 2) if succ else None

    times = [r['time_ms'] for r in rows if r['time_ms'] is not None]
    ttnts = [r['ttnt_median_ms'] for r in rows if r['ttnt_median_ms'] is not None]

    summary_rows.append({
        'participant': p,
        'test'      : t,
        'haptik'    : h,
        'trials'    : N,
        'success_rate_pct' : succ_rate,
        'time_ms_median'   : med(times),
        'time_ms_mean'     : avg(times),
        'ttnt_median_ms_median' : med(ttnts) if ttnts else None,
        'misclicks_total_mean'   : avg([r['misclicks_total'] for r in rows]),
        'repeat_clicks_mean'     : avg([r['repeat_clicks'] for r in rows]),
        'hover_total_mean'       : avg([r['hover_total'] for r in rows]),
        'first_input_ms_median'  : med([r['first_input_ms'] for r in rows]),
        'path_px_mean'           : avg([r['path_px'] for r in rows]),
        'scroll_px_mean'         : avg([r['scroll_px'] for r in rows]),
        'resizes_mean'           : avg([r['resizes'] for r in rows]),
        'key_activations_mean'   : avg([r['keys_activations'] for r in rows]),
        'pointer_activations_mean': avg([r['pointer_activations'] for r in rows]),
    })

# Write summary_by_participant_test_condition.csv
sum_cols = list(summary_rows[0].keys())
with open(os.path.join(OUT_DIR, 'summary_by_participant_test_condition.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=sum_cols)
    w.writeheader()
    for row in summary_rows:
        w.writerow(row)

# ---------- Within-subject deltas (ON - OFF) per participant×test ----------

# index summaries by (participant, test, haptik)
idx = {(r['participant'], r['test'], r['haptik']): r for r in summary_rows}
delta_rows = []
metrics_for_delta = [
    'success_rate_pct', 'time_ms_median', 'time_ms_mean',
    'ttnt_median_ms_median', 'misclicks_total_mean', 'repeat_clicks_mean',
    'hover_total_mean', 'first_input_ms_median', 'path_px_mean',
    'scroll_px_mean', 'resizes_mean', 'key_activations_mean', 'pointer_activations_mean'
]

participants = sorted(set(r['participant'] for r in summary_rows))
tests        = sorted(set(r['test']       for r in summary_rows))

for p in participants:
    for t in tests:
        on  = idx.get((p,t,'on'))
        off = idx.get((p,t,'off'))
        if not on or not off:
            continue
        row = {'participant': p, 'test': t}
        for m in metrics_for_delta:
            a = on.get(m); b = off.get(m)
            if a is None or b is None:
                row[m + '_delta_ON_minus_OFF'] = None
            else:
                row[m + '_delta_ON_minus_OFF'] = round(a - b, 3)
        delta_rows.append(row)

if delta_rows:
    delta_cols = list(delta_rows[0].keys())
    with open(os.path.join(OUT_DIR, 'condition_deltas.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=delta_cols)
        w.writeheader()
        for r in delta_rows:
            w.writerow(r)

# ---------- Overall summary (study-level, by test × haptik) ----------

overall_groups = defaultdict(list)
for r in summary_rows:
    overall_groups[(r['test'], r['haptik'])].append(r)

overall = []
for (t, h), rows in overall_groups.items():
    overall.append({
        'test'   : t,
        'haptik' : h,
        'participants'        : len(rows),
        'success_rate_pct_mean': avg([r['success_rate_pct'] for r in rows]),
        'time_ms_median_mean'  : avg([r['time_ms_median'] for r in rows]),
        'time_ms_mean_mean'    : avg([r['time_ms_mean'] for r in rows]),
        'ttnt_median_ms_median_mean': avg([r['ttnt_median_ms_median'] for r in rows]),
        'misclicks_total_mean_mean' : avg([r['misclicks_total_mean'] for r in rows]),
        'path_px_mean_mean'    : avg([r['path_px_mean'] for r in rows]),
    })

ov_cols = list(overall[0].keys())
with open(os.path.join(OUT_DIR, 'overall_summary.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=ov_cols)
    w.writeheader()
    for r in overall:
        w.writerow(r)

# ---------- Mirror key outputs as JSON ----------

summary_payload = {
    'files_loaded' : files,
    'trials_n'     : len(merged),
    'by_participant_test_condition' : summary_rows,
    'condition_deltas'              : delta_rows,
    'overall'                       : overall
}
with open(os.path.join(OUT_DIR, 'summary.json'), 'w', encoding='utf-8') as f:
    json.dump(summary_payload, f, indent=2, ensure_ascii=False)

print(f"Done. Wrote outputs to: {OUT_DIR}")
