# Windows → ESP32 haptic bridge (cursor fingerprinting, click-down only)
# Arrow  -> STOP (once on transition)   [suppressed for 120 ms after a click]
# Hand   -> P2   (once on transition)
# Others -> P3   (once on transition)
# Clicks -> "CLICK <left|right|middle|xbutton> down"   (only DOWN is sent)
#
# Requires: pyserial, pywin32
# Usage:    py haptic_cursor_bridge_win32hook.py COM5 40

import sys, time, threading, hashlib
import serial, win32gui, win32con

# --- Improve stdout flushing so prints appear immediately ---
try:
    sys.stdout.reconfigure(line_buffering=True, write_through=True)  # py3.7+
except Exception:
    pass

# --- Win32/ctypes setup ---
import ctypes
from ctypes import wintypes

def _ptr_t(signed=False): return ctypes.c_ssize_t if signed else ctypes.c_size_t
HANDLE    = getattr(wintypes, "HANDLE", ctypes.c_void_p)
HINSTANCE = getattr(wintypes, "HINSTANCE", HANDLE)
HWND      = getattr(wintypes, "HWND", HANDLE)
HHOOK     = getattr(wintypes, "HHOOK", HANDLE)
HBITMAP   = getattr(wintypes, "HBITMAP", HANDLE)
HICON     = getattr(wintypes, "HICON", HANDLE)
DWORD     = getattr(wintypes, "DWORD", ctypes.c_uint32)
UINT      = getattr(wintypes, "UINT", ctypes.c_uint)
WPARAM    = getattr(wintypes, "WPARAM", _ptr_t(False))
LPARAM    = getattr(wintypes, "LPARAM", _ptr_t(True))
LRESULT   = getattr(wintypes, "LRESULT", _ptr_t(True))
ULONG_PTR = getattr(wintypes, "ULONG_PTR", ctypes.c_size_t)
LPCWSTR   = getattr(wintypes, "LPCWSTR", ctypes.c_wchar_p)

SYSTEM_IDC_NAMES = [
    "IDC_ARROW", "IDC_HAND", "IDC_IBEAM", "IDC_WAIT", "IDC_APPSTARTING",
    "IDC_CROSS", "IDC_UPARROW", "IDC_SIZEALL", "IDC_SIZENWSE", "IDC_SIZENESW",
    "IDC_SIZEWE", "IDC_SIZENS", "IDC_NO", "IDC_HELP",
    "IDC_PIN", "IDC_PERSON"
]

def build_system_cursor_map():
    """
    Return {fingerprint: 'name'} for all standard IDC_* cursors on *this* system
    Anything not in this map is 'custom'.
    """
    fp_to_name = {}
    for nm in SYSTEM_IDC_NAMES:
        cid = getattr(win32con, nm, None)
        if cid is None:
            continue
        try:
            hcur = win32gui.LoadCursor(0, cid)
            fp = cursor_fingerprint(hcur)
            if fp and fp != "none":
                # Normalize nice short names like 'arrow', 'ibeam', 'sizewe', ...
                short = nm.lower().replace("idc_", "")
                fp_to_name[fp] = short
        except Exception:
            pass
    return fp_to_name


class POINT(ctypes.Structure):
    _fields_ = (("x", wintypes.LONG), ("y", wintypes.LONG))

if hasattr(wintypes, "MSG"):
    MSG = wintypes.MSG
else:
    class MSG(ctypes.Structure):
        _fields_ = (("hwnd", HWND), ("message", UINT), ("wParam", WPARAM),
                    ("lParam", LPARAM), ("time", DWORD), ("pt", POINT))

# Hook consts
WH_MOUSE_LL   = 14
WM_QUIT       = 0x0012
WM_LBUTTONDOWN= 0x0201; WM_LBUTTONUP  = 0x0202
WM_RBUTTONDOWN= 0x0204; WM_RBUTTONUP  = 0x0205
WM_MBUTTONDOWN= 0x0207; WM_MBUTTONUP  = 0x0208
WM_XBUTTONDOWN= 0x020B; WM_XBUTTONUP  = 0x020C
HC_ACTION     = 0

class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = (
        ("pt", POINT),
        ("mouseData", DWORD),
        ("flags", DWORD),
        ("time", DWORD),
        ("dwExtraInfo", ULONG_PTR),
    )

class ICONINFO(ctypes.Structure):
    _fields_ = (("fIcon", wintypes.BOOL),
                ("xHotspot", DWORD),
                ("yHotspot", DWORD),
                ("hbmMask", HBITMAP),
                ("hbmColor", HBITMAP))

class BITMAP(ctypes.Structure):
    _fields_ = (("bmType", ctypes.c_long),
                ("bmWidth", ctypes.c_long),
                ("bmHeight", ctypes.c_long),
                ("bmWidthBytes", ctypes.c_long),
                ("bmPlanes", ctypes.c_ushort),
                ("bmBitsPixel", ctypes.c_ushort),
                ("bmBits", ctypes.c_void_p))

user32   = ctypes.WinDLL("user32", use_last_error=True)
gdi32    = ctypes.WinDLL("gdi32",  use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

LowLevelMouseProc = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, WPARAM, LPARAM)

# Function prototypes
user32.SetWindowsHookExW.argtypes = (ctypes.c_int, LowLevelMouseProc, HINSTANCE, DWORD)
user32.SetWindowsHookExW.restype  = HHOOK
user32.CallNextHookEx.argtypes    = (HHOOK, ctypes.c_int, WPARAM, LPARAM)
user32.CallNextHookEx.restype     = LRESULT
user32.UnhookWindowsHookEx.argtypes = (HHOOK,)
user32.UnhookWindowsHookEx.restype  = wintypes.BOOL
user32.GetMessageW.argtypes       = (ctypes.POINTER(MSG), HWND, UINT, UINT)
user32.GetMessageW.restype        = wintypes.BOOL
user32.TranslateMessage.argtypes  = (ctypes.POINTER(MSG),)
user32.DispatchMessageW.argtypes  = (ctypes.POINTER(MSG),)

user32.CopyIcon.argtypes    = (HICON,)
user32.CopyIcon.restype     = HICON
# IMPORTANT: GetIconInfo has no 'W' suffix
GETICONINFO = getattr(user32, "GetIconInfo")
GETICONINFO.argtypes = (HICON, ctypes.POINTER(ICONINFO))
GETICONINFO.restype  = wintypes.BOOL

user32.DestroyIcon.argtypes = (HICON,)

gdi32.GetObjectW.argtypes   = (HANDLE, ctypes.c_int, ctypes.c_void_p)
gdi32.GetObjectW.restype    = ctypes.c_int
gdi32.GetBitmapBits.argtypes= (HBITMAP, ctypes.c_long, ctypes.c_void_p)
gdi32.GetBitmapBits.restype = ctypes.c_long
gdi32.DeleteObject.argtypes = (HANDLE,)
gdi32.DeleteObject.restype  = wintypes.BOOL

kernel32.GetModuleHandleW.argtypes = (LPCWSTR,)
kernel32.GetModuleHandleW.restype  = HINSTANCE

BAUD = 115200
CLICK_GUARD_MS = 120  # suppress STOP for this long after a click (matches ESP)

def now(): return time.strftime("%H:%M:%S")
def now_ms(): return int(time.time()*1000)
def hex_handle(h):
    try: return f"0x{int(h) & 0xFFFFFFFFFFFFFFFF:X}"
    except: return f"{h!r}"

def _bmp_bytes(hbm: HBITMAP):
    """Return (bytes, (w,h,bpp)) using UNSIGNED buffer to avoid ValueError."""
    if not hbm: return b"", (0,0,0)
    bm = BITMAP()
    if gdi32.GetObjectW(hbm, ctypes.sizeof(bm), ctypes.byref(bm)) == 0:
        return b"", (0,0,0)
    size = max(0, abs(bm.bmHeight) * bm.bmWidthBytes)
    if size == 0:
        return b"", (bm.bmWidth, bm.bmHeight, bm.bmBitsPixel)
    buf = (ctypes.c_ubyte * size)()
    got = gdi32.GetBitmapBits(hbm, size, ctypes.byref(buf))
    if got <= 0:
        return b"", (bm.bmWidth, bm.bmHeight, bm.bmBitsPixel)
    data = bytes(bytearray(buf)[:got])
    meta = (bm.bmWidth, bm.bmHeight, bm.bmBitsPixel)
    return data, meta

def cursor_fingerprint(hcursor) -> str:
    """Hash of (hotspot, mask-bitmap, color-bitmap). Stable across themes."""
    if not hcursor: return "none"
    copy = user32.CopyIcon(hcursor)
    if not copy: return f"h:{int(hcursor)}"
    ii = ICONINFO()
    if not GETICONINFO(copy, ctypes.byref(ii)):
        user32.DestroyIcon(copy)
        return f"h:{int(hcursor)}"
    try:
        mbytes, mmeta = _bmp_bytes(ii.hbmMask)
        cbytes, cmeta = _bmp_bytes(ii.hbmColor)
        h = hashlib.sha1()
        h.update(f"{ii.xHotspot},{ii.yHotspot}|{mmeta}|{cmeta}".encode())
        h.update(mbytes); h.update(cbytes)
        fp = h.hexdigest()
    finally:
        if ii.hbmMask:  gdi32.DeleteObject(ii.hbmMask)
        if ii.hbmColor: gdi32.DeleteObject(ii.hbmColor)
        user32.DestroyIcon(copy)
    return fp

def build_known_fps():
    """Grab fingerprints for Arrow & Hand on this system."""
    return {
        "arrow": cursor_fingerprint(win32gui.LoadCursor(0, win32con.IDC_ARROW)),
        "hand":  cursor_fingerprint(win32gui.LoadCursor(0, win32con.IDC_HAND)),
        # Add more if you want special handling later, e.g.:
        # "ibeam": cursor_fingerprint(win32gui.LoadCursor(0, win32con.IDC_IBEAM)),
    }

# --- Serial reader ---
def serial_reader(sp: serial.Serial, stop_evt: threading.Event):
    while not stop_evt.is_set():
        try:
            line = sp.readline()
            if line:
                try: text = line.decode("utf-8", errors="replace").rstrip("\r\n")
                except: text = repr(line)
                print(f"{now()}  ESP<< {text}")
        except Exception as e:
            print(f"[WARN] Serial read error: {e}")
            time.sleep(0.2)

# --- Mouse hook for click-down only ---
class MouseHook:
    def __init__(self, on_click_down):
        self.on_click_down = on_click_down
        self._hook = None
        self._proc = None
        self._thread = None
        self._tid = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        while self._tid is None: time.sleep(0.01)

    def stop(self):
        if self._tid: user32.PostThreadMessageW(self._tid, WM_QUIT, 0, 0)
        if self._thread: self._thread.join(timeout=1.0)

    def _run(self):
        self._tid = kernel32.GetCurrentThreadId()

        @LowLevelMouseProc
        def _cb(nCode, wParam, lParam):
            if nCode == HC_ACTION:
                info = ctypes.cast(lParam, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                x, y = info.pt.x, info.pt.y
                if wParam in (WM_LBUTTONDOWN, WM_RBUTTONDOWN, WM_MBUTTONDOWN, WM_XBUTTONDOWN):
                    if   wParam == WM_LBUTTONDOWN: btn = "left"
                    elif wParam == WM_RBUTTONDOWN: btn = "right"
                    elif wParam == WM_MBUTTONDOWN: btn = "middle"
                    else:                          btn = "xbutton"
                    try: self.on_click_down(btn, x, y)
                    except: pass
            return user32.CallNextHookEx(self._hook, nCode, wParam, lParam)

        self._proc = _cb
        self._hook = user32.SetWindowsHookExW(WH_MOUSE_LL, self._proc, kernel32.GetModuleHandleW(None), 0)
        if not self._hook:
            print(f"[ERROR] SetWindowsHookEx failed: {ctypes.get_last_error()}")
            return

        msg = MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        if self._hook: user32.UnhookWindowsHookEx(self._hook); self._hook = None

# --- replace your build_known_fps() and the init block in main() with this ---

def main():
    if len(sys.argv) < 2:
        print("Usage: py haptic_cursor_bridge_win32hook.py <COM_PORT> [poll_ms]")
        sys.exit(1)

    port = sys.argv[1]
    poll_ms = int(sys.argv[2]) if len(sys.argv) > 2 else 40
    poll_ms = max(10, poll_ms)

    try:
        sp = serial.Serial(port, BAUD, timeout=0.1, write_timeout=0.2)
    except Exception as e:
        print(f"Failed to open {port}: {e}")
        sys.exit(2)

    print(f"Connected to {port} @{BAUD}")
    print("Arrow/System/None→STOP (with click hold-off), Hand→P2, Custom→P3. Click DOWN forwarded.\n")

    # Build the system-cursor fingerprint map (respects current theme)
    system_map = build_system_cursor_map()
    # Keep explicit arrow/hand fingerprints handy for fast compares/logging
    arrow_fp = cursor_fingerprint(win32gui.LoadCursor(0, win32con.IDC_ARROW))
    hand_fp  = cursor_fingerprint(win32gui.LoadCursor(0, win32con.IDC_HAND))
    print(f"[init] system_cursors={len(system_map)}  arrow_fp={arrow_fp[:8]}… hand_fp={hand_fp[:8]}…")

    # Serial reader
    stop_evt = threading.Event()
    t_reader = threading.Thread(target=serial_reader, args=(sp, stop_evt), daemon=True)
    t_reader.start()

    # Click forwarding (DOWN only)
    last_click_ms = 0
    def on_click_down(btn, x, y):
        nonlocal last_click_ms
        last_click_ms = now_ms()
        try:
            sp.write(f"CLICK {btn} down\n".encode())
        except Exception as e:
            print(f"[WARN] Serial write failed: {e}")
        print(f"{now()}  CLICK {btn:<6} down  @ ({x},{y})  → ESP>> CLICK {btn} down", flush=True)

    hook = MouseHook(on_click_down=on_click_down)
    hook.start()

    # Cursor tracking with transition-based emission + STOP hold-off
    last_category = None
    last_fp = None
    last_handle = None

    try:
        while True:
            flags, hcur, (x, y) = win32gui.GetCursorInfo()
            visible = (flags & 1) != 0

            # Recompute fingerprint only when handle changes
            if hcur != last_handle:
                fp = cursor_fingerprint(hcur)
            else:
                fp = last_fp

            # --- NEW classification logic ---
            if not visible or not hcur or fp == "none":
                category = "none"
                sys_name = "none"
            elif fp == arrow_fp:
                category = "arrow"
                sys_name = "arrow"
            elif fp == hand_fp:
                category = "hand"
                sys_name = "hand"
            elif fp in system_map:
                category = "system"    # standard Windows cursor but not arrow/hand
                sys_name = system_map.get(fp, "?")
            else:
                category = "custom"    # true custom (e.g., CSS url(...) or app-provided)
                sys_name = "custom"

            # Act on transitions (and when a new custom FP appears)
            if (category != last_category) or (category == "custom" and fp != last_fp):
                try:
                    if category in ("arrow", "system", "none"):
                        # suppress STOP if a click just fired (keep in sync with ESP guard)
                        if now_ms() - last_click_ms >= CLICK_GUARD_MS:
                            sp.write(b"STOP\n")
                            print(f"{now()}  Cursor={sys_name:<9} fp={fp[:8]}… Visible={int(visible)} → ESP>> STOP")
                        else:
                            print(f"{now()}  Cursor={sys_name:<9} (STOP suppressed due to recent click)")
                    elif category == "hand":
                        sp.write(b"P2\n")
                        print(f"{now()}  Cursor=hand      fp={fp[:8]}… Visible={int(visible)} → ESP>> P2")
                    else:  # custom
                        sp.write(b"P3\n")
                        print(f"{now()}  Cursor=custom    fp={fp[:8]}… Visible={int(visible)} → ESP>> P3")
                except Exception as e:
                    print(f"[WARN] Serial write failed: {e}")

                last_category = category
                last_fp = fp
                last_handle = hcur

            time.sleep(poll_ms / 1000.0)
    except KeyboardInterrupt:
        pass
    finally:
        stop_evt.set()
        try: sp.close()
        except: pass
        hook.stop()
        print("\nStopped.")

if __name__ == "__main__":
    main()
