// options.js
const DEFAULTS = {
  roles: ["button"],
  cursorPath: "images/cursor.svg",
  hotspotX: 0,
  hotspotY: 0,
  fallback: "pointer"
};

function toDisplayRoles(value) {
  if (Array.isArray(value)) return value.join(", ");
  return value || "";
}

document.addEventListener("DOMContentLoaded", () => {
  const rolesEl     = document.getElementById("roles");
  const pathEl      = document.getElementById("cursorPath");
  const xEl         = document.getElementById("hotspotX");
  const yEl         = document.getElementById("hotspotY");
  const fallbackEl  = document.getElementById("fallback");
  const saveBtn     = document.getElementById("save");
  const statusEl    = document.getElementById("status");

  chrome.storage.sync.get(DEFAULTS, (cfg) => {
    rolesEl.value    = toDisplayRoles(cfg.roles);
    pathEl.value     = cfg.cursorPath;
    xEl.value        = cfg.hotspotX;
    yEl.value        = cfg.hotspotY;
    fallbackEl.value = cfg.fallback;
  });

  saveBtn.addEventListener("click", () => {
    const rolesText = rolesEl.value.trim();
    const roles = rolesText
      ? rolesText.split(/[,\s]+/).map(r => r.trim()).filter(Boolean)
      : DEFAULTS.roles;

    const payload = {
      roles,
      cursorPath: pathEl.value.trim() || DEFAULTS.cursorPath,
      hotspotX: Number(xEl.value) || 0,
      hotspotY: Number(yEl.value) || 0,
      fallback: fallbackEl.value || DEFAULTS.fallback
    };

    chrome.storage.sync.set(payload, () => {
      statusEl.textContent = "Saved.";
      setTimeout(() => (statusEl.textContent = ""), 1200);
    });
  });
});
