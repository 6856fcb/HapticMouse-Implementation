// content.js (simplified: HTML/CSS selectors only)
// Applies a custom cursor to elements matched by the provided CSS selectors.

const DEFAULTS = {
  // e.g., ["button", "a[href]", 'input[type="submit"]']
  //images/aero_arrow.cur, images/cursor.svg
  selectors: ["button"],
  cursorPath: "images/cursor.png",
  hotspotX: 11,
  hotspotY: 8,
  fallback: "none"
};

function normalizeSelectors(val) {
  if (!val) return DEFAULTS.selectors;
  if (Array.isArray(val)) {
    return val.map(s => String(s).trim()).filter(Boolean);
  }
  // Allow comma/space-separated strings
  return String(val)
    .split(/[,\n]+/)
    .map(s => s.trim())
    .filter(Boolean);
}

function applyStyle({ selectors, cursorPath, hotspotX, hotspotY, fallback }) {
  const selectorList = normalizeSelectors(selectors);
  const selector = selectorList.join(", ");
  const url = chrome.runtime.getURL(cursorPath);

  const STYLE_ID = "aria-role-cursor-style";
  let styleEl = document.getElementById(STYLE_ID);
  if (!styleEl) {
    styleEl = document.createElement("style");
    styleEl.id = STYLE_ID;
    (document.head || document.documentElement).appendChild(styleEl);
  }

  const hasNumbers = Number.isFinite(hotspotX) && Number.isFinite(hotspotY);

  // Build a correct cursor value in both cases:
  // - with coords:   url(...) X Y, fallback
  // - without coords: url(...), fallback
  const cursorValue = hasNumbers
    ? `url("${url}") ${hotspotX} ${hotspotY}, ${fallback}`
    : `url("${url}"), ${fallback}`;

  styleEl.textContent = `
${selector} {
  cursor: ${cursorValue} !important;
}
`;
}


function init() {
  // Read everything the user might have set; fall back to DEFAULTS.
  chrome.storage.sync.get(DEFAULTS, (cfg) => {
    applyStyle({
      selectors: cfg.selectors,           // <-- use this key going forward
      cursorPath: cfg.cursorPath || DEFAULTS.cursorPath,
      hotspotX: Number.isFinite(cfg.hotspotX) ? cfg.hotspotX : DEFAULTS.hotspotX,
      hotspotY: Number.isFinite(cfg.hotspotY) ? cfg.hotspotY : DEFAULTS.hotspotY,
      fallback: cfg.fallback || DEFAULTS.fallback
    });
  });

  // Live-update when options change
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    chrome.storage.sync.get(DEFAULTS, applyStyle);
  });
}

init();
